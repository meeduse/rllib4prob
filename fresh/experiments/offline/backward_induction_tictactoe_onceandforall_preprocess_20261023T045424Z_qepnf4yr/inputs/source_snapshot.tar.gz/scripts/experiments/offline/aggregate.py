#!/usr/bin/env python3
"""Aggregate old validated IVI CSVs and new generic offline CSVs for the paper.

Never edits original run folders. Limits and finite-horizon completions stay distinct.
"""
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
import statistics

from summarize import COLUMNS

FIELDS=['campaignId','sourceSchema','algorithm','environment','rewardStrategy','explorationStrategy',
        'run','seed','status','validationState','issue','exploredStates','iterations','updates',
        'horizon','completedHorizon','bellmanResidual','policyResidual',
        'explorationSeconds','orderingSeconds','learningSeconds','totalSeconds',
        'totalBackups','rewardLookups','csvSource','logFile']


def main():
    ap=argparse.ArgumentParser(description='Create analysis CSVs from raw campaign results (without rerunning)')
    ap.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[3])
    ap.add_argument('--output',type=Path,default=None)
    args=ap.parse_args()
    root=args.project.resolve()
    destination=(args.output.resolve() if args.output else root/'analysis')
    destination.mkdir(parents=True,exist_ok=True)
    rows=[]
    for path in sorted((root/'experiments').rglob('results.csv')):
        with path.open(encoding='utf-8',newline='') as source:
            reader=csv.DictReader(source)
            if not reader.fieldnames:
                continue
            names=set(reader.fieldnames)
            if 'schemaVersion' in names and 'validationState' in names:
                schema='offline-common-v1'
            elif 'rewardStrategy' in names and 'bellmanResidual' in names and 'seed' in names and 'explorationStrategy' in names:
                schema='ivi-legacy'
            else:
                print('SKIP unsupported CSV:',path)
                continue
            for i,r in enumerate(reader):
                out={key:'' for key in FIELDS}
                for key in FIELDS:
                    if key in r:
                        out[key]=r[key]
                out['campaignId']=path.parent.name
                out['sourceSchema']=schema
                out['csvSource']=path.relative_to(root).as_posix()
                if schema=='ivi-legacy':
                    out['algorithm']='INCREMENTAL_VALUE_ITERATION'
                    out['environment']='tictacembedded' if r.get('rewardStrategy')=='EMBEDDED' else 'tictactoe'
                    out['run']=str(i)
                    valid=(r.get('status')=='CONVERGED' and not r.get('issue')
                           and r.get('processExitCode')=='0')
                    # Old IVI summarizers checked residual vs threshold; recheck too.
                    if valid:
                        try:
                            residual=float(r['bellmanResidual']); theta=float(r['theta'])
                            import math
                            valid=math.isfinite(residual) and math.isfinite(theta) and 0 <= residual <= theta
                        except (ValueError,TypeError,KeyError):
                            valid=False
                    if valid:
                        out['validationState']='VERIFIED_SUCCESS'
                    elif (r.get('status','').endswith('LIMIT_REACHED')
                          and r.get('processExitCode')=='0'
                          and r.get('issue','') in ('', 'NON_CONVERGED')):
                        out['validationState']='VERIFIED_NONCONVERGENCE'
                    elif r.get('issue'):
                        out['validationState']='INVALID'
                    else:
                        out['validationState']='OTHER_TERMINATION'
                    out['issue']=r.get('issue','')
                rows.append(out)
    dest=destination/'results_all.csv'
    with dest.open('w',encoding='utf-8',newline='') as output:
        writer=csv.DictWriter(output,fieldnames=FIELDS)
        writer.writeheader(); writer.writerows(rows)
    groups=defaultdict(list)
    for r in rows:
        key=(r['algorithm'],r['environment'],r['rewardStrategy'],r['explorationStrategy'])
        groups[key].append(r)
    summary=[]
    for group,vals in sorted(groups.items()):
        success=[v for v in vals if v['validationState']=='VERIFIED_SUCCESS']
        nonconverged=[v for v in vals if v['validationState']=='VERIFIED_NONCONVERGENCE']
        invalid=[v for v in vals if v['validationState'] in ('INVALID','INCOMPLETE')]
        record=dict(zip(['algorithm','environment','rewardStrategy','explorationStrategy'],group))
        record.update(totalRuns=len(vals),verifiedSuccess=len(success),verifiedNonconvergence=len(nonconverged),
                      invalidOrIncomplete=len(invalid))
        for key in ('totalSeconds','explorationSeconds','learningSeconds','totalBackups','iterations','updates'):
            numbers=[]
            for v in success:
                try:
                    import math
                    f=float(v[key])
                    if math.isfinite(f): numbers.append(f)
                except (TypeError,ValueError):
                    pass
            record[key+'Mean']=f'{statistics.mean(numbers):.6f}' if numbers else ''
            record[key+'SampleSD']=f'{statistics.stdev(numbers):.6f}' if len(numbers)>1 else ''
        summary.append(record)
    hdr=['algorithm','environment','rewardStrategy','explorationStrategy','totalRuns','verifiedSuccess',
         'verifiedNonconvergence','invalidOrIncomplete','reportedStatuses']
    for key in ('totalSeconds','explorationSeconds','learningSeconds','totalBackups','iterations','updates'):
        hdr.extend([key+'Mean',key+'SampleSD'])
    with (destination/'summary_by_configuration.csv').open('w',encoding='utf-8',newline='') as output:
        writer=csv.DictWriter(output,fieldnames=hdr)
        writer.writeheader(); writer.writerows(summary)
    print(f'Aggregated {len(rows)} runs from {len(set(r["csvSource"] for r in rows))} campaign folders.')
    print('Detailed:',dest)
    print('Comparison:',destination/'summary_by_configuration.csv')
    print('These summaries do not constitute a significance test; count all budget-limited runs separately.')


if __name__=='__main__':
    main()
